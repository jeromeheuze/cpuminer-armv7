./cpuminer -a yespowerSUGAR -o stratum+tcp://asia.zergpool.com:6535 -u YOUR_BTC_ADDRESS -p c=BTC,mc=SUGAR
