# cpuminer-armv7

Precompiled CPU miner for ARMv7 devices like NanoPi Neo.

## Included Algorithms:
- yescrypt (BSTY)
- yespowerr16 (YTN)
- yespowerSUGAR (SUGAR)
- yespowerADVC (ADVC)

## How to Use

```bash
chmod +x cpuminer *.sh
./start-sugar.sh
```

## Optional: Rotate between coins

```bash
./rotate.sh
```

Replace `YOUR_WALLET` with your actual wallet or BTC address for auto-convert payout at Zergpool.
